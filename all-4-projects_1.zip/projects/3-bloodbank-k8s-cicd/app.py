from flask import Flask, render_template, request, redirect, url_for, jsonify
import sqlite3
import os

app = Flask(__name__)
DB_PATH = 'bloodbank.db'

# Initialize database
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS donors (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            name        TEXT NOT NULL,
            blood_group TEXT NOT NULL,
            phone       TEXT,
            city        TEXT,
            units       INTEGER DEFAULT 1
        )
    ''')
    # Insert sample data
    cursor.execute("SELECT COUNT(*) FROM donors")
    if cursor.fetchone()[0] == 0:
        sample_donors = [
            ('Ravi Kumar',   'A+', '9876543210', 'Hyderabad', 2),
            ('Priya Sharma', 'B+', '8765432109', 'Bangalore', 1),
            ('Arun Singh',   'O+', '7654321098', 'Chennai',   3),
            ('Meena Reddy',  'AB+','6543210987', 'Mumbai',    1),
        ]
        cursor.executemany(
            "INSERT INTO donors (name, blood_group, phone, city, units) VALUES (?,?,?,?,?)",
            sample_donors
        )
    conn.commit()
    conn.close()

@app.route('/')
def index():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    donors = conn.execute("SELECT * FROM donors").fetchall()
    conn.close()
    return render_template('index.html', donors=donors)

@app.route('/add', methods=['GET', 'POST'])
def add_donor():
    if request.method == 'POST':
        conn = sqlite3.connect(DB_PATH)
        conn.execute(
            "INSERT INTO donors (name, blood_group, phone, city, units) VALUES (?,?,?,?,?)",
            (request.form['name'], request.form['blood_group'],
             request.form['phone'], request.form['city'], request.form['units'])
        )
        conn.commit()
        conn.close()
        return redirect(url_for('index'))
    return render_template('add_donor.html')

@app.route('/search')
def search():
    blood_group = request.args.get('bg', '')
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    donors = conn.execute(
        "SELECT * FROM donors WHERE blood_group = ?", (blood_group,)
    ).fetchall()
    conn.close()
    return render_template('index.html', donors=donors, search=blood_group)

@app.route('/health')
def health():
    return jsonify({'status': 'healthy', 'app': 'Blood Bank Application'})

if __name__ == '__main__':
    init_db()
    app.run(host='0.0.0.0', port=5000)
