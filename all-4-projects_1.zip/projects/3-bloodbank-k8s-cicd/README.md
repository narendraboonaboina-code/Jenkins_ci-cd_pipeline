# 🩸 Blood Bank Application — CI/CD Pipeline with Kubernetes

## 📌 Project Overview
A CI/CD pipeline for a Blood Bank web application using Jenkins and Kubernetes. The pipeline automates code quality checks, Docker image builds, security scanning, and Kubernetes deployment.

## 🛠️ Technologies Used
| Tool | Purpose |
|------|---------|
| Jenkins | CI/CD Pipeline Automation |
| Git | Source Code Management |
| SonarQube | Code Quality Analysis |
| Docker | Containerization |
| Trivy | Container Image Security Scanning |
| DockerHub | Container Image Registry |
| Kubernetes | Container Orchestration & Deployment |

## 🔄 CI/CD Pipeline Flow
```
Developer pushes code to Git
           ↓
    Jenkins triggers pipeline
           ↓
   SonarQube Code Analysis
           ↓
     Quality Gate Check
           ↓
    Docker Image Build
           ↓
  Trivy Security Scan (HIGH/CRITICAL CVEs)
           ↓
   Push Image to DockerHub
           ↓
  Deploy to Kubernetes Cluster
           ↓
  kubectl rollout status check
```

## 📁 Project Structure
```
bloodbank-k8s-cicd/
├── Jenkinsfile           # Full CI/CD pipeline
├── app.py                # Flask web application
├── Dockerfile            # Container image definition
├── requirements.txt      # Python dependencies
├── k8s/
│   └── deployment.yaml   # Kubernetes Deployment + Service
└── README.md
```

## 🚀 How to Run Locally
```bash
# Clone repo
git clone https://github.com/YOUR_USERNAME/bloodbank-k8s-cicd.git
cd bloodbank-k8s-cicd

# Build Docker image
docker build -t bloodbank-app .

# Run container
docker run -p 5000:5000 bloodbank-app

# App available at: http://localhost:5000
```

## ☸️ Deploy to Kubernetes
```bash
# Apply deployment
kubectl apply -f k8s/deployment.yaml

# Check pods running
kubectl get pods

# Check service
kubectl get svc

# Access app at: http://NODE_IP:30080
```

## 🔒 Security Scanning with Trivy
```bash
# Install Trivy
sudo apt install trivy -y

# Scan image
trivy image bloodbank-app:latest
```

## ✅ Key Features
- ✅ Automated pipeline — git push triggers everything
- ✅ Code quality enforced before Docker build
- ✅ Security scanning before pushing to registry
- ✅ Kubernetes manages pods with health checks
- ✅ 2 replicas running for high availability
