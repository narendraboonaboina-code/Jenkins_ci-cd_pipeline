package com.myapp;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

public class HelloServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><body>");
        out.println("<h1>🚀 My Java App - Deployed via Jenkins CI/CD!</h1>");
        out.println("<p>Build successful and deployed automatically.</p>");
        out.println("</body></html>");
    }
}
