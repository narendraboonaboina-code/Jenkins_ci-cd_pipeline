from flask import Flask, render_template, request, redirect, url_for
import mysql.connector
import os

app = Flask(__name__)

# Database connection config (from environment variables)
db_config = {
    'host': os.environ.get('DB_HOST', 'db'),
    'user': os.environ.get('DB_USER', 'root'),
    'password': os.environ.get('DB_PASSWORD', 'password'),
    'database': os.environ.get('DB_NAME', 'digital_library')
}

def get_db():
    return mysql.connector.connect(**db_config)

# ---------- HOME PAGE ----------
@app.route('/')
def index():
    conn = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SELECT * FROM books")
    books = cursor.fetchall()
    conn.close()
    return render_template('index.html', books=books)

# ---------- ADD BOOK ----------
@app.route('/add', methods=['GET', 'POST'])
def add_book():
    if request.method == 'POST':
        title  = request.form['title']
        author = request.form['author']
        genre  = request.form['genre']
        year   = request.form['year']

        conn   = get_db()
        cursor = conn.cursor()
        cursor.execute(
            "INSERT INTO books (title, author, genre, year) VALUES (%s, %s, %s, %s)",
            (title, author, genre, year)
        )
        conn.commit()
        conn.close()
        return redirect(url_for('index'))

    return render_template('add_book.html')

# ---------- DELETE BOOK ----------
@app.route('/delete/<int:book_id>')
def delete_book(book_id):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM books WHERE id = %s", (book_id,))
    conn.commit()
    conn.close()
    return redirect(url_for('index'))

# ---------- SEARCH ----------
@app.route('/search')
def search():
    query = request.args.get('q', '')
    conn  = get_db()
    cursor = conn.cursor(dictionary=True)
    cursor.execute(
        "SELECT * FROM books WHERE title LIKE %s OR author LIKE %s",
        (f'%{query}%', f'%{query}%')
    )
    books = cursor.fetchall()
    conn.close()
    return render_template('index.html', books=books, search=query)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
