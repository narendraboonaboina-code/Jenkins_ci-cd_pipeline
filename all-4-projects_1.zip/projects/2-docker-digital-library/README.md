# 🐳 Digital Library Application — Python & Docker

## 📌 Project Overview
A Python Flask web application for managing a digital book library, fully containerized using Docker and Docker Compose. The app connects to a MySQL database running in a separate container.

## 🛠️ Technologies Used
| Tool | Purpose |
|------|---------|
| Python (Flask) | Web application framework |
| MySQL | Database for storing books |
| Docker | Containerization of the app |
| Docker Compose | Multi-container orchestration |
| Git | Source code management |
| Linux | Operating system |

## 🏗️ Architecture
```
┌─────────────────────────────────────┐
│         Docker Network              │
│                                     │
│  ┌─────────────┐  ┌──────────────┐  │
│  │  Flask App  │→ │  MySQL DB    │  │
│  │  Port: 5000 │  │  Port: 3306  │  │
│  └─────────────┘  └──────────────┘  │
└─────────────────────────────────────┘
```

## 📁 Project Structure
```
docker-digital-library/
├── app.py               # Flask application (CRUD + Search)
├── Dockerfile           # Docker image for Flask app
├── docker-compose.yml   # Multi-container setup (App + DB)
├── requirements.txt     # Python dependencies
├── init.sql             # Database schema + sample data
└── README.md
```

## 🚀 How to Run

### Prerequisites
- Docker installed
- Docker Compose installed

### Run the App
```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/docker-digital-library.git
cd docker-digital-library

# Build and start both containers
docker-compose up --build

# App will be available at:
# http://localhost:5000
```

### Stop the App
```bash
docker-compose down
```

## ✅ Features
- 📚 View all books in the library
- ➕ Add new books
- 🔍 Search books by title or author
- 🗑️ Delete books
- 🔗 Flask app automatically connects to MySQL container

## 🔍 Useful Docker Commands
```bash
# Check running containers
docker ps

# View app logs
docker logs digital-library-app

# Access MySQL inside container
docker exec -it digital-library-db mysql -u root -p

# Stop and remove everything
docker-compose down -v
```
