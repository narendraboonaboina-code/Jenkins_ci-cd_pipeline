-- Create and use the database
CREATE DATABASE IF NOT EXISTS digital_library;
USE digital_library;

-- Create books table
CREATE TABLE IF NOT EXISTS books (
    id     INT AUTO_INCREMENT PRIMARY KEY,
    title  VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    genre  VARCHAR(100),
    year   INT
);

-- Insert sample data
INSERT INTO books (title, author, genre, year) VALUES
('The Pragmatic Programmer', 'Andrew Hunt', 'Technology', 1999),
('Clean Code',               'Robert C. Martin', 'Technology', 2008),
('Harry Potter',             'J.K. Rowling', 'Fantasy', 1997),
('The Alchemist',            'Paulo Coelho', 'Fiction', 1988);
