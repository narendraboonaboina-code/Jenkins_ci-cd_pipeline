# Install Prometheus + Grafana using Helm
# Run these commands after EKS cluster is ready

# Step 1: Add Helm repo
helm repo add prometheus-community https://prometheus-community.github.io/helm-charts
helm repo update

# Step 2: Create monitoring namespace
kubectl create namespace monitoring

# Step 3: Install Prometheus + Grafana stack
helm install prometheus prometheus-community/kube-prometheus-stack \
  --namespace monitoring \
  --set grafana.adminPassword=admin123 \
  --set prometheus.prometheusSpec.retention=7d

# Step 4: Check pods
kubectl get pods -n monitoring

# Step 5: Access Grafana dashboard
kubectl port-forward svc/prometheus-grafana 3000:80 -n monitoring
# Open: http://localhost:3000
# Login: admin / admin123
