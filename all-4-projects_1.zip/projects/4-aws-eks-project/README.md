# ☁️ End-to-End Kubernetes Project on AWS EKS

## 📌 Project Overview
A production-grade 3-tier web application deployed on AWS EKS (Elastic Kubernetes Service) using Terraform for infrastructure provisioning and Kubernetes for container orchestration, with Prometheus and Grafana for monitoring.

## 🛠️ Technologies Used
| Tool | Purpose |
|------|---------|
| AWS EKS | Managed Kubernetes Cluster |
| Terraform | Infrastructure as Code (IaC) |
| Kubernetes | Container Orchestration |
| Jenkins | CI/CD Pipeline |
| Docker | Containerization |
| SonarQube | Code Quality Analysis |
| Trivy | Container Security Scanning |
| Prometheus | Metrics Collection |
| Grafana | Monitoring Dashboards |
| Git | Source Code Management |

## 🏗️ Architecture
```
                    Internet
                       │
               ┌───────────────┐
               │  AWS Load     │
               │  Balancer     │
               └───────┬───────┘
                       │
          ┌────────────────────────┐
          │       AWS EKS          │
          │                        │
          │  ┌──────────────────┐  │
          │  │  Frontend (Nginx) │  │
          │  │  2 Pods          │  │
          │  └────────┬─────────┘  │
          │           │            │
          │  ┌────────▼─────────┐  │
          │  │  Backend (Flask) │  │
          │  │  2-10 Pods (HPA) │  │
          │  └────────┬─────────┘  │
          │           │            │
          │  ┌────────▼─────────┐  │
          │  │  AWS RDS MySQL   │  │
          │  └──────────────────┘  │
          └────────────────────────┘
                       │
          ┌────────────────────────┐
          │   Prometheus + Grafana │
          │   (Monitoring Stack)   │
          └────────────────────────┘
```

## 📁 Project Structure
```
aws-eks-project/
├── terraform/
│   ├── main.tf           # VPC + EKS cluster setup
│   └── variables.tf      # Configuration variables
├── k8s/
│   └── deployment.yaml   # Frontend, Backend, HPA, Secrets
├── monitoring/
│   └── setup-monitoring.sh   # Prometheus + Grafana setup
└── README.md
```

## 🚀 Step-by-Step Setup

### Step 1 — Configure AWS CLI
```bash
aws configure
# Enter: Access Key, Secret Key, Region (us-east-1)
```

### Step 2 — Provision EKS with Terraform
```bash
cd terraform/
terraform init
terraform plan
terraform apply -auto-approve
# Wait ~15 mins for EKS cluster creation
```

### Step 3 — Connect kubectl to EKS
```bash
aws eks update-kubeconfig --name my-eks-cluster --region us-east-1
kubectl get nodes   # Should show worker nodes
```

### Step 4 — Deploy Application
```bash
kubectl apply -f k8s/deployment.yaml
kubectl get pods    # Check all pods running
kubectl get svc     # Get Load Balancer URL
```

### Step 5 — Setup Monitoring
```bash
bash monitoring/setup-monitoring.sh
# Access Grafana at: http://localhost:3000
```

## ✅ Key Features
- ✅ EKS cluster provisioned fully with Terraform (IaC)
- ✅ 3-tier architecture: Frontend → Backend → Database
- ✅ Auto-scaling: 2 to 10 pods based on CPU (HPA)
- ✅ Load balancer created automatically by AWS
- ✅ Secrets management using Kubernetes Secrets
- ✅ Prometheus collects metrics from all pods
- ✅ Grafana dashboards for real-time monitoring

## 🔧 Useful Commands
```bash
# Check cluster
kubectl get nodes
kubectl get pods --all-namespaces

# Scale manually
kubectl scale deployment backend-deployment --replicas=5

# Check HPA status
kubectl get hpa

# View logs
kubectl logs -f deployment/backend-deployment

# Destroy infrastructure
terraform destroy -auto-approve
```
